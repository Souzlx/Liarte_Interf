@echo off
setlocal
title LIARTE - Abrir Power BI
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Configurar_e_Abrir.ps1"
if errorlevel 1 (
  echo.
  echo Nao foi possivel abrir o projeto. Consulte o arquivo LEIA-ME.txt.
  pause
)
endlocal
