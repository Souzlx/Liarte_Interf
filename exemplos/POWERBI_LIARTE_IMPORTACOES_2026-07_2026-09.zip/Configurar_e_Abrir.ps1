$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Excels = @(Get-ChildItem -LiteralPath (Join-Path $Root "Dados") -Filter "*.xlsx" -File)
if ($Excels.Count -ne 1) { throw "A pasta Dados deve conter exatamente uma planilha Excel." }
$Excel = $Excels[0]

$Tmdl = Join-Path $Root "LIARTE_Importacoes.SemanticModel\definition\expressions.tmdl"
if (-not (Test-Path -LiteralPath $Tmdl -PathType Leaf)) { throw "O modelo semântico está incompleto." }
$Content = [System.IO.File]::ReadAllText($Tmdl)
$SafePath = $Excel.FullName.Replace('#(', '#(#)(').Replace('"', '""')
$Pattern = '(?m)^expression CaminhoArquivoExcel = ".*" meta'
$Replacement = 'expression CaminhoArquivoExcel = "' + $SafePath + '" meta'
$Evaluator = [System.Text.RegularExpressions.MatchEvaluator] { param($Match) $Replacement }
$Updated = [System.Text.RegularExpressions.Regex]::Replace($Content, $Pattern, $Evaluator)
if ($Updated -eq $Content -and $Content -notmatch [regex]::Escape($SafePath)) {
    throw "Não foi possível configurar o caminho do Excel no modelo semântico."
}
[System.IO.File]::WriteAllText($Tmdl, $Updated, (New-Object System.Text.UTF8Encoding($false)))

$Pbip = Join-Path $Root "LIARTE_Importacoes.pbip"
if (-not (Test-Path -LiteralPath $Pbip -PathType Leaf)) { throw "O arquivo PBIP não foi encontrado." }
Start-Process -FilePath $Pbip
